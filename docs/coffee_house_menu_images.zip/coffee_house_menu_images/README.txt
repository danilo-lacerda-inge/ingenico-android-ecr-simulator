Coffee House menu illustrations
24 square PNG files, standardized to 512x512 pixels.
Style source: one cohesive illustrated menu sheet, cropped into individual products.
Product labels are omitted from the individual images.
